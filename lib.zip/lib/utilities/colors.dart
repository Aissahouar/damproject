import 'package:flutter/material.dart';

// ignore: constant_identifier_names
const Primaryclr = Color(0xffd99156);